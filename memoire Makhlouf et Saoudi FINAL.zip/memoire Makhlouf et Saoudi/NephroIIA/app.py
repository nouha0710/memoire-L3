from flask import Flask, render_template, request, redirect, url_for, flash, session
import pickle
import numpy as np

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Nécessaire pour session et flash

# === Chargement des objets ===
MODELS = {
    'svm_linear': pickle.load(open('svm_best_model_linear.pkl', 'rb')),
    'svm_rbf': pickle.load(open('svm_best_model_rbf.pkl', 'rb')),
    'svm_poly': pickle.load(open('svm_best_model_poly.pkl', 'rb')),
    'svm_sigmoid': pickle.load(open('svm_best_model_sigmoid.pkl', 'rb')),
    'mlp': pickle.load(open('mlp_model.pkl', 'rb')),
}

with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

with open('encodings.pkl', 'rb') as f:
    encodings = pickle.load(f)

with open('feature_order.pkl', 'rb') as f:
    feature_order = pickle.load(f)

# === Variables catégorielles ===
categorical_columns = ['physical_activity', 'diet', 'smoking', 'alcohol',
                       'painkiller_usage', 'family_history', 'weight_changes',
                       'stress_level']

categorical_options = {
    col: list(encodings[col].keys()) for col in categorical_columns
}

# === Page de login ===
@app.route("/", methods=["GET", "POST"])
def login():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def handle_login():
    role = request.form.get("role")
    password = request.form.get("password")

    if role == "medecin" and password == "med123":
        session['role'] = 'medecin'
        return redirect(url_for("form_medecin"))
    elif role == "informaticien" and password == "info123":
        session['role'] = 'informaticien'
        return redirect(url_for("form_informaticien"))
    else:
        flash("Identifiants incorrects.")
        return redirect(url_for("login"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# === Formulaires ===
@app.route("/medecin")
def form_medecin():
    if session.get('role') != 'medecin':
        return redirect(url_for("login"))
    return render_template("medecin.html", categorical_options=categorical_options)

@app.route("/informaticien")
def form_informaticien():
    if session.get('role') != 'informaticien':
        return redirect(url_for("login"))
    return render_template("informaticien.html", categorical_options=categorical_options)

# === Fonction d'information sur les stades ===
def get_stade_info(stade):
    definitions = {
        0: "Stage 0 (Normal kidney function): At this stage, the kidneys are functioning properly, and there is no evidence of damage. It is essential to maintain a healthy lifestyle and monitor kidney health, especially if there are risk factors such as diabetes or hypertension.",
        1: "Stage 1 (Mild kidney damage): There may be slight kidney damage, but the kidneys still function well. Early detection is key. Patients should focus on managing underlying conditions like high blood pressure or diabetes and adopt kidney-friendly habits.",
        2: "Stage 2 (Moderate kidney damage): Kidney function begins to decline slightly. It’s important to monitor kidney function closely, control blood sugar and pressure levels, and start making dietary adjustments to reduce kidney strain.",
        3: "Stage 3 (Moderate to severe kidney failure): This stage is divided into 3A and 3B. Waste starts to build up in the blood, and symptoms like fatigue, swelling, and changes in urination may appear. Treatment plans should be discussed with a nephrologist.",
        4: "Stage 4 (Severe kidney failure): Kidney function is severely reduced, and complications become more serious. This stage is a critical preparation period for dialysis or a kidney transplant. Frequent monitoring and strict medical management are essential.",
        5: "Stage 5 (End-stage renal disease): The kidneys can no longer maintain body balance, and dialysis or kidney transplant is required. Patients need intensive medical care and support to manage life with kidney failure."
    }

    conseils = {
    0: [
        "Maintain good hydration",
        "Avoid nephrotoxic medications",
        "Regular check-ups"
    ],
    1: [
        "Adopt a balanced diet",
        "Monitor blood pressure",
        "Engage in moderate physical activity"
    ],
    2: [
        "Limit protein intake",
        "Monitor creatinine levels",
        "Reduce salt consumption"
    ],
    3: [
        "Consult a nephrologist",
        "Treat metabolic complications",
        "Prepare for renal replacement therapy"
    ],
    4: [
        "Prepare for dialysis",
        "Strict dietary control",
        "Avoid infections"
    ],
    5: [
        "Regular follow-up with a nephrologist",
        "Undergo dialysis or kidney transplant",
        "Seek psychological support"
    ]
}

    return definitions.get(stade, "Stade inconnu."), conseils.get(stade, [])

# === Prédiction ===
@app.route("/predict", methods=["POST"])
def predict():
    if 'role' not in session:
        return redirect(url_for("login"))

    form_data = request.form
    model_name = form_data.get("model", "mlp")  # Par défaut MLP

    # Fonction de conversion sécurisée
    def safe_float(value, default=0.0):
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    # Préparer les données dans le bon ordre avec encodage/casting
    input_data = {}
    for col in feature_order:
        val = form_data.get(col)
        if col in encodings:
            val = encodings[col].get(val, 0)  # Encodage catégoriel
        else:
            val = safe_float(val)  # Conversion float sécurisée
        input_data[col] = val

    # Mettre les features dans l'ordre attendu par les modèles
    ordered_input = [input_data[col] for col in feature_order]
    input_scaled = scaler.transform([ordered_input])

    # === Cas médecin : prédiction avec un seul modèle
    if session['role'] == 'medecin':
        model = MODELS[model_name]
        prediction = model.predict(input_scaled)[0]
        stade_def, stade_conseils = get_stade_info(prediction)
        return render_template("result_medecin.html", prediction=prediction,
                               stade_def=stade_def, stade_conseils=stade_conseils)

    # === Cas informaticien : prédiction avec tous les modèles
    elif session['role'] == 'informaticien':
        predictions = {}
        for name, model in MODELS.items():
            predictions[name] = model.predict(input_scaled)[0]
        return render_template("result_informaticien.html", predictions=predictions)

    return redirect(url_for("login"))

# === Lancer l'application ===
if __name__ == "__main__":
    app.run(debug=True)
