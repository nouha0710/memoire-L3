import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import pickle
from typing import Literal

# Charger les données
file_path = 'updated_ckd_dataset_with_stages(1).csv'
df = pd.read_csv(file_path)

print("Informations générales sur les données :")
print(df.info())
print("\nValeurs manquantes par colonne :")
print(df.isnull().sum())

# === Étape 1 : Encodage manuel des colonnes catégorielles ===
categorical_columns = [
    'physical_activity', 'diet', 'smoking', 'alcohol',
    'painkiller_usage', 'family_history', 'weight_changes',
    'stress_level', 'ckd_pred'
]

encodings = {}
for col in categorical_columns:
    unique_values = df[col].unique().tolist()
    mapping = {val: idx for idx, val in enumerate(unique_values)}
    encodings[col] = mapping
    df[col] = df[col].map(mapping)

# === Étape 2 : Séparation des variables ===
X = df.drop(columns=['ckd_stage', 'ckd_pred'])  # ckd_pred n'est pas utilisé pour l'entraînement
y = df['ckd_stage']

# === Étape 3 : Normalisation sur toutes les features d'entrée ===
scaler = StandardScaler()
X = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

# === Étape 4 : Split des données ===
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# === Étape 5 : Entraînement SVM avec plusieurs noyaux ===
kernels: list[Literal['linear', 'poly', 'rbf', 'sigmoid']] = ['linear', 'poly', 'rbf', 'sigmoid']
best_model = None
best_accuracy = 0
best_kernel = None

for kernel in kernels:
    print(f"\n### Évaluation du noyau SVM : {kernel} ###")
    model = SVC(kernel=kernel, probability=True, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print(classification_report(y_test, y_pred))

    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title(f'Matrice de confusion - SVM ({kernel})')
    plt.xlabel('Prédits')
    plt.ylabel('Réels')
    plt.tight_layout()
    plt.show()

    accuracy = model.score(X_test, y_test)
    print(f"Précision du modèle avec noyau {kernel} : {accuracy:.4f}")
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = model
        best_kernel = kernel

# === Sauvegarde du meilleur modèle SVM ===
if best_model:
    print(f"\n✅ Meilleur SVM : {best_kernel} avec précision = {best_accuracy:.4f}")
    with open(f'svm_best_model_{best_kernel}.pkl', 'wb') as f:
        pickle.dump(best_model, f)

# === Entraînement MLPClassifier ===
print("\n### Entraînement du réseau de neurones MLPClassifier ###")
mlp_model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=500, random_state=42)
mlp_model.fit(X_train, y_train)

y_pred_mlp = mlp_model.predict(X_test)
print("\nRapport de classification - MLP :")
print(classification_report(y_test, y_pred_mlp))

cm_mlp = confusion_matrix(y_test, y_pred_mlp)
plt.figure(figsize=(6, 4))
sns.heatmap(cm_mlp, annot=True, fmt='d', cmap='Greens')
plt.title('Matrice de confusion - MLP')
plt.xlabel('Prédits')
plt.ylabel('Réels')
plt.tight_layout()
plt.show()

# === Sauvegardes ===
with open('mlp_model.pkl', 'wb') as f:
    pickle.dump(mlp_model, f)

with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

with open('encodings.pkl', 'wb') as f:
    pickle.dump(encodings, f)

feature_order = X.columns.tolist()
with open('feature_order.pkl', 'wb') as f:
    pickle.dump(feature_order, f)

print("\n Sauvegardes terminées :")
print("  - svm_best_model_<kernel>.pkl")
print("  - mlp_model.pkl")
print("  - scaler.pkl")
print("  - encodings.pkl")
print("  - feature_order.pkl")
